import { Routes, Route, Link, useLocation, Navigate } from "react-router-dom";
import Home from "./pages/Home";
import Register from "./pages/Register";
import Login from "./pages/Login";
import StaffDashboard from "./pages/StaffDashboard";
import StudentDashboard from "./pages/StudentDashboard";
import CourseDetails from "./pages/CourseDetails";
import "./App.css";

function App() {
  const location = useLocation();
  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role");

  // Paths where navbar should NOT be shown
  const hideNavbarRoutes = [
    "/staff-dashboard",
    "/student-dashboard",
    "/course",
  ];

  // Check if current path should hide navbar
  const shouldHideNavbar = hideNavbarRoutes.some(route => 
    location.pathname.startsWith(route)
  );

  return (
    <>
      Navbar only when NOT on dashboard/course pages
      {!shouldHideNavbar && (
        <nav className="main-navbar">
          <div className="nav-container">
            <div className="nav-logo">
              <Link to="/">
                <h2>SmartAttend</h2>
              </Link>
            </div>
            <div className="nav-links">
              <Link to="/">Home</Link>
              <Link to="/register">Register</Link>
              <Link to="/login">Login</Link>
            </div>
          </div>
        </nav>
      )}

      <Routes>
        {/* Homepage Route */}
        <Route path="/" element={<Home />} />

        {/* Public Routes */}
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />

        {/* Staff Dashboard */}
        <Route
          path="/staff-dashboard"
          element={
            token && role === "staff" ? (
              <StaffDashboard />
            ) : (
              <Navigate to="/login" />
            )
          }
        />

        {/* Student Dashboard */}
        <Route
          path="/student-dashboard"
          element={
            token && role === "student" ? (
              <StudentDashboard />
            ) : (
              <Navigate to="/login" />
            )
          }
        />

        {/* Course Details (accessible only if logged in) */}
        <Route
          path="/course/:id"
          element={
            token ? (
              <CourseDetails />
            ) : (
              <Navigate to="/login" />
            )
          }
        />

        {/* Default Redirect */}
        <Route
          path="*"
          element={
            <Navigate to={token ? `/${role}-dashboard` : "/"} />
          }
        />
      </Routes>
    </>
  );
}

export default App;