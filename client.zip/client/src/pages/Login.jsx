import React, { useState } from "react";
import "./Auth.css";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    role: "student",
  });
  const navigate = useNavigate();

  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const endpoint =
        formData.role === "student"
          ? "http://localhost:5000/api/students/login"
          : "http://localhost:5000/api/staff/login";

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (!res.ok) {
        alert("❌ " + (data.message || "Login failed"));
        return;
      }

      if (data.token) {
        localStorage.setItem("token", data.token);
        localStorage.setItem("role", formData.role);
      }

      alert("✅ Login successful"); 
      navigate(formData.role === "staff" ? "/staff-dashboard" : "/student-dashboard");
    } catch (err) {
      console.error(err);
      alert("⚠️ Could not connect to server");
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <h2 className="auth-title">Login</h2>

        {/* Role Switch */}
        <div className="auth-role-toggle">
          {["student", "staff"].map((role) => (
            <button
              key={role}
              type="button"
              className={`role-btn ${formData.role === role ? "active" : ""}`}
              onClick={() => setFormData({ ...formData, role })}
            >
              {role.charAt(0).toUpperCase() + role.slice(1)}
            </button>
          ))}
        </div>

        <form className="auth-form" onSubmit={handleSubmit}>
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            required
          />
          <button type="submit" className="auth-button">
            Login
          </button>
        </form>

        <p className="auth-footer">
          Don’t have an account? <a href="/register">Register</a>
        </p>
      </div>
    </div>
  );
}
