import React, { useState } from "react";
import "./Auth.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
export default function Register() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    department: "",
    rollNumber: "",
    year: "",
    role: "student",
  });

  const [photo, setPhoto] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
const handleSubmit = async (e) => {
  e.preventDefault();

  if (!photo) {
    alert("Please select a photo!");
    return;
  }

  const body = new FormData();
  body.append("name", formData.name);
  body.append("roll_no", formData.rollNumber); // match Flask backend

  try {
    const response = await axios.post("http://localhost:5000/register", body, {
      headers: { "Content-Type": "multipart/form-data" }
    });

    console.log("Server response:", response.data);
  } catch (error) {
    console.error("Registration error:", error.response?.data || error.message);
  }
};

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     try {
//       let body;
//       let headers = {};
//       let endpoint;

//       if (formData.role === "student") {
//         body = new FormData();
// body.append("name", formData.name);
// body.append("email", formData.email);
// body.append("password", formData.password);
// body.append("department", formData.department);
// body.append("rollNumber", formData.rollNumber);
// body.append("year", formData.year);
//         if (photo) body.append("photo", photo);
//         endpoint = "http://localhost:5000/api/students/register";
//       } else {
//         body = JSON.stringify(formData);
//         headers["Content-Type"] = "application/json";
//         endpoint = "http://localhost:5000/api/staff/register";
//       }
 

//       const res = await fetch(endpoint, {
//         method: "POST",
//         body,
//         headers,
//       });

//       const data = await res.json();
//       console.log("Response:", data);

//       if (res.ok) {
//         alert("✅ Registered Successfully!");
//         setFormData({
//           name: "",
//           email: "",
//           password: "",
//           department: "",
//           rollNumber: "",
//           year: "",
//           role: "student",
//         });
//         setPhoto(null);
//         navigate("/login");
//       } else {
//         alert("❌ Error: " + (data.message || data.error));
//       }
//     } catch (err) {
//       console.error("Frontend Error:", err);
//       alert("⚠️ Could not connect to server");
//     }
//   };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <h2 className="auth-title">Create an Account</h2>

        {/* Role Tabs */}
        <div className="role-tabs">
          {["student", "staff"].map((r) => (
            <button
              key={r}
              type="button"
              className={`role-tab ${formData.role === r ? "active" : ""}`}
              onClick={() => setFormData({ ...formData, role: r })}
            >
              {r.charAt(0).toUpperCase() + r.slice(1)}
            </button>
          ))}
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="auth-form">
          <input
            type="text"
            name="name"
            placeholder="Full Name"
            value={formData.name}
            onChange={handleChange}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Email Address"
            value={formData.email}
            onChange={handleChange}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Create Password"
            value={formData.password}
            onChange={handleChange}
            required
          />
          <input
            type="text"
            name="department"
            placeholder="Department"
            value={formData.department}
            onChange={handleChange}
          />

          {formData.role === "student" && (
            <>
              <input
                type="text"
                name="rollNumber"
                placeholder="Roll Number"
                value={formData.rollNumber}
                onChange={handleChange}
                required
              />
              <input
                type="number"
                name="year"
                placeholder="Year (1-4)"
                value={formData.year}
                onChange={handleChange}
                required
              />

              <label className="upload-label">
                Upload Photo
               <input
  type="file"
  name="photo"  // important: matches Flask backend key
  onChange={(e) => setPhoto(e.target.files[0])}
/>


              </label>

              
            </>
          )}

          <button type="submit" className="auth-button">
            Register as {formData.role.charAt(0).toUpperCase() + formData.role.slice(1)}
          </button>
        </form>
      </div>
    </div>
  );
}
