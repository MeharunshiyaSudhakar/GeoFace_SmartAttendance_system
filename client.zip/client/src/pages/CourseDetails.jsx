import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../api";


function ViewStudentsPage() {
  const { id } = useParams(); // courseId from URL
  const token = localStorage.getItem("token");
  const [students, setStudents] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [sessionId, setSessionId] = useState(null);

  useEffect(() => {
  const fetchData = async () => {
    try {
      const sessionRes = await axios.get(
        "http://localhost:5000/api/attendance/active-sessions",
        { headers: { Authorization: `Bearer ${token}` } }
      );

      const session = sessionRes.data.sessions.find((s) => s.courseId?._id === id);
      if (session) {
        setSessionId(session._id);

        const attRes = await axios.get(
          `http://localhost:5000/api/attendance/session/${session._id}/students`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setAttendance(attRes.data || []);
      }
    } catch (err) {
      console.error("Error fetching students:", err.response?.data || err.message);
    }
  };

  fetchData();
}, [id, token]);
const presentCount = attendance.filter((a) => a.status === "Present").length;

return (
  <div>
    <h2>Attendance List</h2>
    <p>
      Present: {attendance.filter((a) => a.status === "Present").length}/
      {attendance.length}
    </p>
    <ul>
      {attendance.map((stu) => (
        <li key={stu._id}>
          {stu.name} ({stu.email}) → <strong>{stu.status}</strong>
        </li>
      ))}
    </ul>
  </div>
);

  // ✅ Check if student is present
  const getStatus = (studentId) => {
    const record = attendance.find((a) => a.student?._id === studentId);
    return record ? "Present" : "Absent";
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Enrolled Students</h2>
      {students.length === 0 ? (
        <p>No students enrolled yet.</p>
      ) : (
        <ul>
          {students.map((stu) => (
            <li key={stu._id}>
              {stu.name} ({stu.email}) → <strong>{getStatus(stu._id)}</strong>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default ViewStudentsPage;
