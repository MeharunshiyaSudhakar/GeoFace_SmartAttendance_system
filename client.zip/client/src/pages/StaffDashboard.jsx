// client/src/pages/StaffDashboard.jsx
import { Link } from "react-router-dom";
import React, { useState, useEffect } from "react";
import axios from "axios";
import api from "../api.js";
import {
  BookOpen,
  Users,
  MessageSquare,
  User,
  Plus,
  Copy,
  LogOut,
  ChevronLeft,
  ChevronRight,
  FileText,
  Mail,
  Phone,
  Calendar,
  FileUp,
  Upload,
  X,
} from "lucide-react";
import { GoogleGenerativeAI } from "@google/generative-ai";
import "./StaffDashboard.css";
import Chat from "../pages/Chat";

const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);
function StaffDashboard() {
  console.log("Gemini Key:", import.meta.env.VITE_GEMINI_API_KEY);
  const [activeSection, setActiveSection] = useState("classrooms");
  const [courses, setCourses] = useState([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newCourse, setNewCourse] = useState({ name: "", description: "" });
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentUser] = useState({
    name: "Dr. Sarah Johnson",
    email: "sarah.johnson@university.edu",
    id: "staff-id",
    department: "Computer Science",
    phone: "+1 (555) 123-4567",
    joinDate: "2022-03-15",
    office: "Building A, Room 304",
  });
  const token = localStorage.getItem("token");
  const [activeSessions, setActiveSessions] = useState([]);
  const [attendanceList, setAttendanceList] = useState([]);

  // For Reports UI
  const [sessionsModalOpen, setSessionsModalOpen] = useState(false);
  const [sessionsForCourse, setSessionsForCourse] = useState([]);
  const [selectedCourseForSessions, setSelectedCourseForSessions] = useState(null);

  const [studentsModalOpen, setStudentsModalOpen] = useState(false);
  const [selectedSession, setSelectedSession] = useState(null);
  const [sessionStudentList, setSessionStudentList] = useState([]);

  // Chat state
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");

  // Assignment state
  const [assignments, setAssignments] = useState([]);
  const [showAssignmentForm, setShowAssignmentForm] = useState(false);
  const [newAssignment, setNewAssignment] = useState({
    title: "",
    description: "",
    courseId: "",
    dueDate: "",
    maxMarks: "",
  });
  const [assignmentFile, setAssignmentFile] = useState(null);

  // Fetch staff courses
  const fetchCourses = async () => {
    try {
      const res = await api.get("/courses/staff");
      setCourses(res.data.courses || []);
    } catch (err) {
      console.error("Error fetching courses:", err.response?.data || err.message);
    }
  };

  // Fetch assignments
  const fetchAssignments = async () => {
    try {
      const res = await api.get("/assignments/staff");
      setAssignments(res.data.assignments || []);
    } catch (err) {
      console.error("Error fetching assignments:", err.response?.data || err.message);
    }
  };

  // Fetch active sessions
  const fetchActiveSessions = async () => {
    try {
      const res = await api.get("/attendance/active-sessions");
      setActiveSessions(res.data.sessions || []);
    } catch (err) {
      console.error("Error fetching active sessions:", err.response?.data || err.message);
    }
  };

  useEffect(() => {
    fetchCourses();
    fetchAssignments();
    fetchActiveSessions();
    const timer = setInterval(() => fetchActiveSessions(), 15_000);
    return () => clearInterval(timer);
  }, []);

  // Create course
  const handleCreateCourse = async (e) => {
    e.preventDefault();
    if (!newCourse.name || !newCourse.description) return alert("Please fill all fields");
    try {
      await api.post("/courses", newCourse);
      setNewCourse({ name: "", description: "" });
      setShowCreateForm(false);
      fetchCourses();
    } catch (err) {
      alert(err.response?.data?.message || "Error creating course");
    }
  };

  // Start attendance session
  const startSession = async (courseId, subject) => {
    try {
      if (!courseId || !subject) return alert("Course ID and subject are required");

      if (!navigator.geolocation) {
        return alert("Geolocation is not supported by your browser");
      }

      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          await api.post("/attendance/start", {
            courseId,
            subject,
            latitude,
            longitude,
            radius: 50,
          });

          alert("✅ Attendance session started!");
          fetchActiveSessions();
        },
        (err) => {
          console.error("Location error:", err);
          alert("Location permission is required to start attendance");
        },
        { enableHighAccuracy: true }
      );
    } catch (err) {
      console.error("Error starting session", err.response?.data || err.message);
      alert(err.response?.data?.message || "Error starting session");
    }
  };

  // End attendance session
  const endSession = async (sessionId) => {
    try {
      await api.post(`/attendance/end/${sessionId}`, {});
      fetchActiveSessions();
      setAttendanceList([]);
      alert("Attendance session ended!");
    } catch (err) {
      alert(err.response?.data?.message || "Error ending session");
    }
  };

  // Copy password helper
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert("Copied!");
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location.href = "/login";
  };

  // Chat functions
  // Gemini Chat Message Function
const sendGeminiMessage = async () => {
  if (!newMessage.trim()) return;

  // add user message
  const userMsg = {
    id: Date.now(),
    text: newMessage,
    sender: "staff",
    timestamp: new Date().toLocaleTimeString(),
  };
  setMessages((prev) => [...prev, userMsg]);

  // store input & clear textarea
  const inputText = newMessage;
  setNewMessage("");

  try {
    // ------------------------------------------------------
    // ✅ THIS IS WHERE YOUR CODE GOES (CORRECT PLACEMENT)
    // ------------------------------------------------------
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    const result = await model.generateContent(inputText);
    const reply = result.response.text();
    // ------------------------------------------------------

    const botMsg = {
      id: Date.now() + 1,
      text: reply,
      sender: "gemini",
      timestamp: new Date().toLocaleTimeString(),
    };

    setMessages((prev) => [...prev, botMsg]);

  } catch (err) {
    console.error("Gemini Error:", err);
    const errorMsg = {
      id: Date.now() + 2,
      text: "Hello! how it's going? ",
      sender: "gemini",
      timestamp: new Date().toLocaleTimeString(),
    };
    setMessages((prev) => [...prev, errorMsg]);
  }
};


  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // Assignment functions
  const handleAssignmentFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAssignmentFile(file);
    }
  };

  const handleCreateAssignment = async (e) => {
    e.preventDefault();
    if (!newAssignment.title || !newAssignment.courseId || !newAssignment.dueDate) {
      return alert("Please fill title, course, and due date");
    }

    try {
      const formData = new FormData();
      formData.append('title', newAssignment.title);
      formData.append('description', newAssignment.description);
      formData.append('courseId', newAssignment.courseId);
      formData.append('dueDate', newAssignment.dueDate);
      formData.append('maxMarks', newAssignment.maxMarks);
      
      if (assignmentFile) {
        formData.append('file', assignmentFile);
      }

      await api.post('/assignments', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      alert('✅ Assignment created successfully!');
      setNewAssignment({
        title: "",
        description: "",
        courseId: "",
        dueDate: "",
        maxMarks: "",
      });
      setAssignmentFile(null);
      setShowAssignmentForm(false);
      fetchAssignments();
    } catch (err) {
      console.error('Error creating assignment:', err.response?.data || err.message);
      alert(err.response?.data?.message || 'Error creating assignment');
    }
  };

  const deleteAssignment = async (assignmentId) => {
    if (!confirm('Are you sure you want to delete this assignment?')) return;
    
    try {
      await api.delete(`/assignments/${assignmentId}`);
      alert('Assignment deleted successfully!');
      fetchAssignments();
    } catch (err) {
      alert(err.response?.data?.message || 'Error deleting assignment');
    }
  };

  // Sessions modal functions
  const openSessionsForCourse = async (course) => {
    try {
      const res = await api.get(`/attendance/sessions/${course._id}`);
      setSessionsForCourse(res.data || []);
      setSelectedCourseForSessions(course);
      setSessionsModalOpen(true);
    } catch (err) {
      console.error("Error fetching sessions for course:", err.response?.data || err.message);
      alert("Failed to load sessions for this course");
    }
  };

  const closeSessionsModal = () => {
    setSessionsModalOpen(false);
    setSessionsForCourse([]);
    setSelectedCourseForSessions(null);
  };

  const openStudentsForSession = async (session) => {
    try {
      const attRes = await api.get(`/attendance/session/${session._id}/attendance`);
      const attendance = attRes.data || [];
      const courseStudentsRes = await api.get(`/courses/${session.courseId._id}/students`);
      const enrolled = courseStudentsRes.data.students || [];

      const presentIds = attendance.map((a) =>
        a.student ? a.student._id.toString() : a.student?.toString()
      );

      const merged = enrolled.map((stu) => ({
        _id: stu._id,
        name: stu.name,
        rollNo: stu.rollNo || stu.email || "—",
        status: presentIds.includes(stu._id.toString()) ? "Present" : "Absent",
      }));

      setSelectedSession(session);
      setSessionStudentList(merged);
      setStudentsModalOpen(true);
    } catch (err) {
      console.error("Error opening students for session:", err.response?.data || err.message);
      alert("Failed to load students for this session");
    }
  };

  const closeStudentsModal = () => {
    setStudentsModalOpen(false);
    setSelectedSession(null);
    setSessionStudentList([]);
  };

  const generatePdfForSession = async (session) => {
    try {
      const res = await api.get(`/attendance/session/${session._id}/pdf`, {
        responseType: "blob",
      });

      const blob = new Blob([res.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const filename = `attendance_${session._id}.pdf`;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Error generating PDF:", err.response?.data || err.message);
      alert("Failed to generate PDF for this session");
    }
  };

  // UI pieces
  const sidebarItems = [
    { id: "classrooms", label: "Classrooms", icon: BookOpen },
    { id: "attendance", label: "Attendance", icon: Users },
    { id: "assignments", label: "Assignments", icon: FileUp },
    { id: "chat", label: "Chat", icon: MessageSquare },
    { id: "profile", label: "Profile", icon: User },
  ];

  // CLASSROOMS view
  const renderClassrooms = () => (
    <div>
      <div className="content-header">
        <h2>My Courses</h2>
        <button className="general-btn" onClick={() => setShowCreateForm(true)}>
          <Plus size={16} /> Create Course
        </button>
      </div>

      {showCreateForm && (
        <div className="card">
          <h3>Create New Course</h3>
          <form onSubmit={handleCreateCourse}>
            <input
              type="text"
              placeholder="Course Name"
              value={newCourse.name}
              onChange={(e) => setNewCourse({ ...newCourse, name: e.target.value })}
            />
            <textarea
              placeholder="Description"
              value={newCourse.description}
              onChange={(e) => setNewCourse({ ...newCourse, description: e.target.value })}
            />
            <div className="form-actions">
              <button type="submit" className="general-btn">
                Create
              </button>
              <button type="button" className="general-btn secondary" onClick={() => setShowCreateForm(false)}>
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="cards-container">
        {courses.map((course) => {
          const session = activeSessions.find((s) => s.courseId?._id === course._id);
          const attendanceActive = session?.active || false;

          return (
            <div key={course._id} className="card">
              <h3>{course.name}</h3>
              <p>{course.description}</p>
              <p>
                <strong>Join Code:</strong> {course.code}
              </p>
              <p>
                <strong>Password:</strong> {course.joinPassword}
              </p>

              <div className="card-actions">
                <button onClick={() => copyToClipboard(course.joinPassword)} className="general-btn">
                  <Copy size={16} /> Copy Password
                </button>

                <button
                  onClick={() => {
                    if (!attendanceActive) startSession(course._id, course.name);
                    else endSession(session._id);
                  }}
                  className={attendanceActive ? "attendance-on" : "attendance-off"}
                >
                  Attendance: {attendanceActive ? "ON" : "OFF"}
                </button>

                <button
                  onClick={() => openSessionsForCourse(course)}
                  className="general-btn"
                >
                  <FileText size={14} /> View Sessions
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  // ATTENDANCE view
  const renderAttendance = () => (
    <div>
      <h2>Attendance Records</h2>
      {activeSessions.length === 0 ? (
        <p>No active session</p>
      ) : (
        activeSessions.map((session) => (
          <div key={session._id} className="card" style={{ marginBottom: 12 }}>
            <h3>
              {session.subject} - {session.courseId?.name}
            </h3>

            <div className="card-actions">
              <Link to={`/course/${session.courseId?._id}`}>
                <button className="general-btn">View Course Students</button>
              </Link>

              <button
                className="general-btn"
                onClick={() => openStudentsForSession(session)}
              >
                View Students Marked
              </button>

              <button
                className="general-btn"
                onClick={() => generatePdfForSession(session)}
              >
                Generate PDF
              </button>

              <button
                className="general-btn"
                onClick={() => endSession(session._id)}
              >
                End Session
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );

  // ASSIGNMENTS view
  const renderAssignments = () => (
    <div>
      <div className="content-header">
        <h2>Assignments</h2>
        <button className="general-btn" onClick={() => setShowAssignmentForm(true)}>
          <Plus size={16} /> Create Assignment
        </button>
      </div>

      {showAssignmentForm && (
        <div className="card">
          <h3>Create New Assignment</h3>
          <form onSubmit={handleCreateAssignment}>
            <input
              type="text"
              placeholder="Assignment Title"
              value={newAssignment.title}
              onChange={(e) => setNewAssignment({ ...newAssignment, title: e.target.value })}
              required
            />
            
            <textarea
              placeholder="Assignment Description"
              value={newAssignment.description}
              onChange={(e) => setNewAssignment({ ...newAssignment, description: e.target.value })}
              rows="3"
            />

            <select
              value={newAssignment.courseId}
              onChange={(e) => setNewAssignment({ ...newAssignment, courseId: e.target.value })}
              required
            >
              <option value="">Select Course</option>
              {courses.map(course => (
                <option key={course._id} value={course._id}>
                  {course.name}
                </option>
              ))}
            </select>

            <div className="form-row">
              <input
                type="datetime-local"
                placeholder="Due Date"
                value={newAssignment.dueDate}
                onChange={(e) => setNewAssignment({ ...newAssignment, dueDate: e.target.value })}
                required
              />
              
              <input
                type="number"
                placeholder="Max Marks"
                value={newAssignment.maxMarks}
                onChange={(e) => setNewAssignment({ ...newAssignment, maxMarks: e.target.value })}
              />
            </div>

            <div className="file-upload">
              <label>
                <Upload size={16} />
                Upload Assignment File (Optional)
                <input
                  type="file"
                  onChange={handleAssignmentFileChange}
                  accept=".pdf,.doc,.docx,.txt,.zip"
                  style={{ display: 'none' }}
                />
              </label>
              {assignmentFile && (
                <div className="file-preview">
                  <FileText size={14} />
                  <span>{assignmentFile.name}</span>
                  <button type="button" onClick={() => setAssignmentFile(null)}>
                    <X size={14} />
                  </button>
                </div>
              )}
            </div>

            <div className="form-actions">
              <button type="submit" className="general-btn">
                <FileUp size={16} /> Create Assignment
              </button>
              <button type="button" className="general-btn secondary" onClick={() => setShowAssignmentForm(false)}>
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="assignments-list">
        {assignments.length === 0 ? (
          <div className="no-data">
            <FileUp size={48} />
            <p>No assignments created yet</p>
          </div>
        ) : (
          assignments.map((assignment) => (
            <div key={assignment._id} className="card assignment-card">
              <div className="assignment-header">
                <h3>{assignment.title}</h3>
                <button 
                  className="delete-btn"
                  onClick={() => deleteAssignment(assignment._id)}
                >
                  <X size={16} />
                </button>
              </div>
              
              <p>{assignment.description}</p>
              
              <div className="assignment-details">
                <div className="detail">
                  <strong>Course:</strong> 
                  <span>{assignment.courseId?.name || 'Unknown Course'}</span>
                </div>
                <div className="detail">
                  <strong>Due Date:</strong> 
                  <span>{new Date(assignment.dueDate).toLocaleString()}</span>
                </div>
                <div className="detail">
                  <strong>Max Marks:</strong> 
                  <span>{assignment.maxMarks || 'N/A'}</span>
                </div>
                {assignment.fileUrl && (
                  <div className="detail">
                    <strong>Attachment:</strong>
                    <a href={assignment.fileUrl} target="_blank" rel="noopener noreferrer" className="file-link">
                      <FileText size={14} /> Download File
                    </a>
                  </div>
                )}
              </div>
              
              <div className="assignment-stats">
                <span className="stat">
                  Submissions: <strong>{assignment.submissionsCount || 0}</strong>
                </span>
                <span className="stat">
                  Created: <strong>{new Date(assignment.createdAt).toLocaleDateString()}</strong>
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );

  // CHAT view
 // CHAT view (Gemini Integrated)
const renderChat = () => (
  <div className="chat-container">
    
    <div className="chat-header">
      <h2>AI Chat Assistant (Gemini)</h2>
      <p>Powered by Google Gemini API</p>
    </div>

    <div className="chat-messages">
      {messages.length === 0 ? (
        <div className="no-messages">
          <MessageSquare size={48} />
          <p>Ask me anything! Start a conversation below.</p>
        </div>
      ) : (
        messages.map((msg) => (
          <div key={msg.id} className={`message ${msg.sender === "staff" ? "sent" : "received"}`}>
            <div className="message-content">
              <p>{msg.text}</p>
              <span className="message-time">{msg.timestamp}</span>
            </div>
          </div>
        ))
      )}
    </div>

    <div className="chat-input-container">
      <textarea
        value={newMessage}
        onChange={(e) => setNewMessage(e.target.value)}
        onKeyPress={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            sendGeminiMessage();   // Updated
          }
        }}
        placeholder="Ask Gemini anything..."
        rows="2"
      />
      <button onClick={sendGeminiMessage} className="general-btn">
        Send
      </button>
    </div>
  </div>
);

  // PROFILE view
  const renderProfile = () => (
    <div className="profile-container">
      <div className="profile-header">
        <h2>Staff Profile</h2>
        <p>Manage your account information and preferences</p>
      </div>

      <div className="profile-content">
        <div className="profile-card">
          <div className="profile-avatar">
            <User size={48} />
          </div>
          
          <div className="profile-info">
            <h3>{currentUser.name}</h3>
            <p className="profile-role">Faculty Member</p>
            
            <div className="profile-details">
              <div className="detail-item">
                <Mail size={18} />
                <div>
                  <label>Email</label>
                  <p>{currentUser.email}</p>
                </div>
              </div>
              
              <div className="detail-item">
                <Phone size={18} />
                <div>
                  <label>Phone</label>
                  <p>{currentUser.phone}</p>
                </div>
              </div>
              
              <div className="detail-item">
                <BookOpen size={18} />
                <div>
                  <label>Department</label>
                  <p>{currentUser.department}</p>
                </div>
              </div>
              
              <div className="detail-item">
                <Calendar size={18} />
                <div>
                  <label>Join Date</label>
                  <p>{new Date(currentUser.joinDate).toLocaleDateString()}</p>
                </div>
              </div>
              
              <div className="detail-item">
                <User size={18} />
                <div>
                  <label>Office</label>
                  <p>{currentUser.office}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="profile-actions">
          <button className="general-btn">
            Edit Profile
          </button>
          <button className="general-btn">
            Change Password
          </button>
          <button className="general-btn logout-btn" onClick={handleLogout}>
            <LogOut size={16} /> Logout
          </button>
        </div>

        <div className="stats-card">
          <h4>Quick Stats</h4>
          <div className="stats-grid">
            <div className="stat-item">
              <span className="stat-number">{courses.length}</span>
              <span className="stat-label">Courses</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">{activeSessions.length}</span>
              <span className="stat-label">Active Sessions</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">{assignments.length}</span>
              <span className="stat-label">Assignments</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case "classrooms":
        return renderClassrooms();
      case "attendance":
        return renderAttendance();
      case "assignments":
        return renderAssignments();
      case "chat":
        return renderChat();
      case "profile":
        return renderProfile();
      default:
        return <h2>Coming Soon</h2>;
    }
  };

  return (
    <div className="dashboard-container">
      <div className={`sidebar ${sidebarOpen ? "open" : "closed"}`}>
        <div className="sidebar-top">
          <User size={24} />
          {sidebarOpen && (
            <div className="user-info">
              <p>{currentUser.name}</p>
              <small>Staff</small>
            </div>
          )}
          <div className="hamburger-inside" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <ChevronLeft /> : <ChevronRight />}
          </div>
        </div>

        <div className="sidebar-items">
          {sidebarItems.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className={`sidebar-item ${activeSection === item.id ? "active" : ""}`}
                onClick={() => setActiveSection(item.id)}
              >
                <Icon size={18} /> {sidebarOpen && <span>{item.label}</span>}
              </div>
            );
          })}
        </div>
      </div>

      <div className="main-content" style={{ marginLeft: sidebarOpen ? "250px" : "80px" }}>
        {renderContent()}
      </div>

      {/* Sessions Modal */}
      {sessionsModalOpen && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Sessions for: {selectedCourseForSessions?.name}</h3>
            <button className="close-btn" onClick={closeSessionsModal}>Close</button>
            <div style={{ marginTop: 12 }}>
              {sessionsForCourse.length === 0 ? (
                <p>No sessions found.</p>
              ) : (
                sessionsForCourse.map((s) => (
                  <div key={s._id} className="card" style={{ marginBottom: 8 }}>
                    <p><strong>Subject:</strong> {s.subject}</p>
                    <p><strong>Started:</strong> {new Date(s.startedAt).toLocaleString()}</p>
                    <p><strong>Active:</strong> {s.active ? "Yes" : "No"}</p>
                    <div className="card-actions">
                      <button onClick={() => openStudentsForSession(s)} className="general-btn">View Students</button>
                      <button onClick={() => generatePdfForSession(s)} className="general-btn">Generate PDF</button>
                      {s.active && <button onClick={() => endSession(s._id)} className="general-btn">End Session</button>}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Students Modal */}
      {studentsModalOpen && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Students — {selectedSession?.courseId?.name} ({selectedSession?.subject})</h3>
            <button className="close-btn" onClick={closeStudentsModal}>Close</button>

            <div style={{ marginTop: 12 }}>
              {sessionStudentList.length === 0 ? (
                <p>No students enrolled / no attendance yet.</p>
              ) : (
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr>
                      <th style={{ textAlign: "left", padding: 6 }}>#</th>
                      <th style={{ textAlign: "left", padding: 6 }}>Name</th>
                      <th style={{ textAlign: "left", padding: 6 }}>Roll / ID</th>
                      <th style={{ textAlign: "left", padding: 6 }}>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sessionStudentList.map((stu, i) => (
                      <tr key={stu._id} style={{ borderTop: "1px solid #eee" }}>
                        <td style={{ padding: 6 }}>{i + 1}</td>
                        <td style={{ padding: 6 }}>{stu.name}</td>
                        <td style={{ padding: 6 }}>{stu.rollNo}</td>
                        <td style={{ padding: 6 }}>{stu.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            <div style={{ marginTop: 12 }}>
              <button onClick={() => generatePdfForSession(selectedSession)} className="general-btn">
                Generate PDF for this session
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default StaffDashboard;