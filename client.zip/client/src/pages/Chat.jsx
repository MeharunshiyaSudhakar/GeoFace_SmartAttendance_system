import React, { useState } from "react";
import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);

export default function GeminiChat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sendMessage = async () => {
    if (!input.trim()) return;

    const newMessages = [...messages, { role: "user", text: input }];
    setMessages(newMessages);

    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    const result = await model.generateContent(input);

    const reply = result.response.text();

    setMessages([...newMessages, { role: "bot", text: reply }]);
    setInput("");
  };

  return (
    <div style={{ width: "100%", maxWidth: "500px", margin: "auto" }}>
      <h2>Educational Chat</h2>

      <div style={{
        border: "1px solid #ccc",
        padding: "10px",
        height: "400px",
        overflowY: "auto",
        marginBottom: "10px"
      }}>
        {messages.map((msg, index) => (
          <div key={index} style={{ 
            textAlign: msg.role === "user" ? "right" : "left", 
            marginBottom: "8px"
          }}>
            <strong>{msg.role === "user" ? "You" : "Gemini"}:</strong>
            <p>{msg.text}</p>
          </div>
        ))}
      </div>

      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Ask me..."
        style={{ width: "75%", padding: "8px" }}
      />
      <button onClick={sendMessage} style={{ width: "23%", marginLeft: "2%" }}>
        Send
      </button>
    </div>
  );
}
