import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css';

const Homepage = () => {
  const navigate = useNavigate();

  const handleLogin = () => {
    navigate('/login');
  };

  const handleRegister = () => {
    navigate('/register');
  };

  const handleGetStarted = () => {
    navigate('/register');
  };

  return (
    <div className="home">
      {/* Silver Floating Particles Background */}
      <div className="particles-background">
        <div className="particle particle-1"></div>
        <div className="particle particle-2"></div>
        <div className="particle particle-3"></div>
        <div className="particle particle-4"></div>
        <div className="particle particle-5"></div>
        <div className="particle particle-6"></div>
        <div className="particle particle-7"></div>
        <div className="particle particle-8"></div>
        <div className="particle particle-9"></div>
        <div className="particle particle-10"></div>
        
        {/* Additional sparkle effects */}
        <div className="sparkle sparkle-1"></div>
        <div className="sparkle sparkle-2"></div>
        <div className="sparkle sparkle-3"></div>
        <div className="sparkle sparkle-4"></div>
        <div className="sparkle sparkle-5"></div>
      </div>

      {/* Navigation */}
      <nav className="home-nav">
        <div className="nav-brand">
          <span className="brand-icon">⚡</span>
          <span className="brand-text">SmartAttendance</span>
        </div>
        <div className="nav-actions">
          <button className="nav-btn login-nav" onClick={handleLogin}>
            Sign In
          </button>
          <button className="nav-btn register-nav" onClick={handleRegister}>
            Get Started
          </button>
        </div>
      </nav>

      {/* Main Hero Section */}
      <section className="hero">
        <div className="hero-container">
          <div className="hero-content">
            <div className="hero-badge">
              <span>🚀 Next Generation Attendance System</span>
            </div>
            
            <h1 className="hero-title">
              Smart Attendance
              <span className="title-gradient"> Reinvented</span>
            </h1>
            
            <p className="hero-description">
              Experience the future of attendance management with our AI-powered platform. 
              Combining facial recognition, geolocation, and real-time analytics for 
              seamless, secure, and automated tracking.
            </p>

            <div className="hero-stats">
              <div className="stat">
                <div className="stat-value">99.9%</div>
                <div className="stat-label">Accuracy Rate</div>
              </div>
              <div className="stat">
                <div className="stat-value">100%</div>
                <div className="stat-label">Secure & Private</div>
              </div>
              <div className="stat">
                <div className="stat-value">24/7</div>
                <div className="stat-label">Reliable Service</div>
              </div>
            </div>

            <div className="hero-actions">
              <button className="cta-btn primary" onClick={handleGetStarted}>
                <span>Start Free Trial</span>
                <div className="btn-sparkle"></div>
              </button>
              <button className="cta-btn secondary" onClick={() => document.getElementById('features').scrollIntoView({ behavior: 'smooth' })}>
                <span>See Features</span>
              </button>
            </div>
          </div>

          <div className="hero-visual">
            <div className="visual-card">
              <div className="card-icon">👁️</div>
              <h4>Face Recognition</h4>
              <p>Advanced AI-powered facial detection with 99.9% accuracy</p>
            </div>
            <div className="visual-card">
              <div className="card-icon">📍</div>
              <h4>Location Tracking</h4>
              <p>Precise geolocation verification with real-time monitoring</p>
            </div>
            <div className="visual-card">
              <div className="card-icon">📊</div>
              <h4>Smart Analytics</h4>
              <p>Comprehensive insights and automated reporting</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features" id="features">
        <div className="container">
          <div className="section-header">
            <h2>Why Choose SmartAttend?</h2>
            <p>Revolutionary features designed for modern institutions</p>
          </div>
          
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">⚡</div>
              <h3>Lightning Fast</h3>
              <p>Mark attendance in seconds with our optimized processing system and real-time synchronization</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">🔒</div>
              <h3>Military Grade Security</h3>
              <p>End-to-end encryption and secure data handling with biometric verification</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">📱</div>
              <h3>Mobile First</h3>
              <p>Access from any device with our responsive design and cross-platform compatibility</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">📈</div>
              <h3>Smart Reports</h3>
              <p>Generate detailed analytics, export reports, and gain valuable insights</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">🔄</div>
              <h3>Real-time Sync</h3>
              <p>Instant updates across all connected devices with cloud backup</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">🎯</div>
              <h3>Precision Tracking</h3>
              <p>Accurate location and time-based verification with anti-spoofing technology</p>
            </div>
          </div>
        </div>
      </section>

      {/* Rest of your sections... */}
    </div>
  );
};

export default Homepage;