import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import {
  BookOpen,
  Users,
  Bell,
  Settings,
  User,
  Copy,
  LogOut,
  ChevronLeft,
  ChevronRight,
  MessageCircle,
  BarChart2,
  ClipboardList,
  Award,
  X,
  TrendingUp,
  Target,
  Crown,
  Medal,
  RefreshCw,
  Camera,
  Save,
  Edit3,
  Mail,
  Phone,
  BookOpen as BookIcon,
  Calendar,
  Send,
} from "lucide-react";
import { GoogleGenerativeAI } from "@google/generative-ai";
import "./StudentDashboard.css";

// Profile Section Component
function ProfileSection({ currentUser, onProfileUpdate }) {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    department: "",
    bio: ""
  });
  const [avatarPreview, setAvatarPreview] = useState("");

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      // Try to get profile from backend
      const res = await axios.get("http://localhost:5000/api/profile/me", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProfile(res.data);
      setFormData({
        name: res.data.name || currentUser.name,
        email: res.data.email || currentUser.email,
        phone: res.data.phone || "",
        department: res.data.department || "",
        bio: res.data.bio || ""
      });
      setAvatarPreview(res.data.avatar);
    } catch (err) {
      console.error("Failed to fetch profile:", err);
      // Fallback to current user data
      setProfile(currentUser);
      setFormData({
        name: currentUser.name,
        email: currentUser.email,
        phone: "",
        department: "",
        bio: ""
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Preview image
      const reader = new FileReader();
      reader.onload = (e) => {
        setAvatarPreview(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = async () => {
    try {
      setSaving(true);
      
      const submitData = new FormData();
      submitData.append('name', formData.name);
      submitData.append('email', formData.email);
      submitData.append('phone', formData.phone);
      submitData.append('department', formData.department);
      submitData.append('bio', formData.bio);
      
      const res = await axios.put(
        "http://localhost:5000/api/profile/me",
        submitData,
        {
          headers: { 
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data'
          },
        }
      );

      setProfile(res.data);
      setEditing(false);
      onProfileUpdate(res.data);
      
      alert("Profile updated successfully!");
    } catch (err) {
      console.error("Failed to update profile:", err);
      // Update locally even if backend fails
      setProfile(formData);
      setEditing(false);
      onProfileUpdate(formData);
      alert("Profile updated locally (backend may be unavailable)");
    } finally {
      setSaving(false);
    }
  };

  const getEnrollmentStats = () => {
    if (!profile) return null;
    
    return {
      totalCourses: 3, // Mock data
      createdCourses: 0,
      memberSince: new Date().getFullYear()
    };
  };

  if (loading) {
    return (
      <div className="profile-section">
        <div className="loading">Loading profile...</div>
      </div>
    );
  }

  const stats = getEnrollmentStats();

  return (
    <div className="profile-section">
      <div className="profile-header">
        <h2>
          <User size={24} />
          My Profile
        </h2>
        <div className="header-actions">
          {!editing ? (
            <button 
              className="edit-btn"
              onClick={() => setEditing(true)}
            >
              <Edit3 size={16} />
              Edit Profile
            </button>
          ) : (
            <div className="edit-actions">
              <button 
                className="cancel-btn"
                onClick={() => {
                  setEditing(false);
                  setFormData({
                    name: profile.name,
                    email: profile.email,
                    phone: profile.phone || "",
                    department: profile.department || "",
                    bio: profile.bio || ""
                  });
                  setAvatarPreview(profile.avatar);
                }}
              >
                Cancel
              </button>
              <button 
                className="save-btn"
                onClick={handleSaveProfile}
                disabled={saving}
              >
                <Save size={16} />
                {saving ? "Saving..." : "Save Changes"}
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="profile-content">
        {/* Profile Overview */}
        <div className="profile-sidebar">
          <div className="avatar-section">
            <div className="avatar-container">
              <img 
                src={avatarPreview || `https://ui-avatars.com/api/?name=${encodeURIComponent(formData.name)}&background=4a6fa5&color=ffffff&size=200`} 
                alt="Profile"
                className="profile-avatar"
              />
              {editing && (
                <label className="avatar-upload">
                  <Camera size={20} />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarChange}
                    style={{ display: 'none' }}
                  />
                </label>
              )}
            </div>
            
            {!editing && (
              <>
                <h3 className="profile-name">{profile.name}</h3>
                <p className="profile-role">Student</p>
                {profile.studentId && (
                  <p className="profile-id">ID: {profile.studentId}</p>
                )}
              </>
            )}
          </div>

          {/* Stats Overview */}
          {stats && (
            <div className="profile-stats">
              <div className="stat-item">
                <BookIcon size={20} />
                <div>
                  <span className="stat-value">{stats.totalCourses}</span>
                  <span className="stat-label">Enrolled Courses</span>
                </div>
              </div>
              
              <div className="stat-item">
                <Calendar size={20} />
                <div>
                  <span className="stat-value">{stats.memberSince}</span>
                  <span className="stat-label">Member Since</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Profile Details */}
        <div className="profile-details">
          <div className="details-tabs">
            <button 
              className={`tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
              onClick={() => setActiveTab('overview')}
            >
              Overview
            </button>
            <button 
              className={`tab-btn ${activeTab === 'courses' ? 'active' : ''}`}
              onClick={() => setActiveTab('courses')}
            >
              Courses
            </button>
          </div>

          <div className="tab-content">
            {activeTab === 'overview' && (
              <div className="overview-tab">
                {editing ? (
                  <div className="edit-form">
                    <div className="form-group">
                      <label>Full Name</label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Enter your full name"
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Email Address</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="Enter your email"
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Phone Number</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="Enter your phone number"
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Department</label>
                      <input
                        type="text"
                        name="department"
                        value={formData.department}
                        onChange={handleInputChange}
                        placeholder="Enter your department"
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Bio</label>
                      <textarea
                        name="bio"
                        value={formData.bio}
                        onChange={handleInputChange}
                        placeholder="Tell us about yourself..."
                        rows="4"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="profile-info">
                    <div className="info-item">
                      <Mail size={18} />
                      <div>
                        <label>Email</label>
                        <p>{profile.email}</p>
                      </div>
                    </div>
                    
                    {profile.phone && (
                      <div className="info-item">
                        <Phone size={18} />
                        <div>
                          <label>Phone</label>
                          <p>{profile.phone}</p>
                        </div>
                      </div>
                    )}
                    
                    {profile.department && (
                      <div className="info-item">
                        <BookIcon size={18} />
                        <div>
                          <label>Department</label>
                          <p>{profile.department}</p>
                        </div>
                      </div>
                    )}
                    
                    {profile.bio && (
                      <div className="info-item">
                        <User size={18} />
                        <div>
                          <label>Bio</label>
                          <p className="bio-text">{profile.bio}</p>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'courses' && (
              <div className="courses-tab">
                <h4>Enrolled Courses</h4>
                <div className="courses-list">
                  <div className="course-item">
                    <div className="course-info">
                      <h5>Mathematics 101</h5>
                      <p>Introduction to Advanced Mathematics</p>
                      <span className="course-code">MATH101</span>
                    </div>
                  </div>
                  <div className="course-item">
                    <div className="course-info">
                      <h5>Computer Science</h5>
                      <p>Programming Fundamentals</p>
                      <span className="course-code">CS101</span>
                    </div>
                  </div>
                  <div className="course-item">
                    <div className="course-info">
                      <h5>Physics Lab</h5>
                      <p>Practical Physics Experiments</p>
                      <span className="course-code">PHYLAB</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Assignment Section Component
function AssignmentSection({ currentUser }) {
  const [assignments, setAssignments] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("available");
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState(null);
  const [submissionForm, setSubmissionForm] = useState({
    submissionType: "file",
    text: "",
    link: "",
    files: []
  });

  const token = localStorage.getItem("token");
  const fileInputRef = useRef(null);

  useEffect(() => {
    fetchCourses();
    fetchSubmissions();
  }, []);

  useEffect(() => {
    if (courses.length > 0) {
      fetchAssignments();
    }
  }, [courses]);

  const fetchCourses = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/courses/student", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCourses(res.data.courses || []);
    } catch (err) {
      console.error("Failed to fetch courses:", err);
    }
  };

  const fetchAssignments = async () => {
    try {
      setLoading(true);
      // Fetch assignments for all enrolled courses
      const assignmentsPromises = courses.map(course =>
        axios.get(`http://localhost:5000/api/assignments/course/${course._id}`, {
          headers: { Authorization: `Bearer ${token}` },
        })
      );

      const results = await Promise.all(assignmentsPromises);
      const allAssignments = results.flatMap(res => res.data);
      setAssignments(allAssignments);
    } catch (err) {
      console.error("Failed to fetch assignments:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchSubmissions = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/assignments/submissions/student", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSubmissions(res.data);
    } catch (err) {
      console.error("Failed to fetch submissions:", err);
    }
  };

  const openSubmitModal = (assignment) => {
    setSelectedAssignment(assignment);
    setSubmissionForm({
      submissionType: assignment.submissionType === 'any' ? 'file' : assignment.submissionType,
      text: "",
      link: "",
      files: []
    });
    setShowSubmitModal(true);
  };

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files);
    setSubmissionForm(prev => ({
      ...prev,
      files: [...prev.files, ...files]
    }));
  };

  const removeFile = (index) => {
    setSubmissionForm(prev => ({
      ...prev,
      files: prev.files.filter((_, i) => i !== index)
    }));
  };

  const handleSubmitAssignment = async () => {
    try {
      const formData = new FormData();
      formData.append('submissionType', submissionForm.submissionType);
      
      if (submissionForm.submissionType === 'text') {
        formData.append('text', submissionForm.text);
      } else if (submissionForm.submissionType === 'link') {
        formData.append('link', submissionForm.link);
      }

      // Add files
      submissionForm.files.forEach(file => {
        formData.append('files', file);
      });

      await axios.post(
        `http://localhost:5000/api/assignments/${selectedAssignment._id}/submit`,
        formData,
        {
          headers: { 
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data'
          },
        }
      );

      alert("Assignment submitted successfully!");
      setShowSubmitModal(false);
      fetchAssignments();
      fetchSubmissions();
    } catch (err) {
      console.error("Failed to submit assignment:", err);
      alert(err.response?.data?.message || "Error submitting assignment");
    }
  };

  const getSubmissionStatus = (assignment) => {
    const submission = submissions.find(s => s.assignment._id === assignment._id);
    if (submission) {
      return {
        submitted: true,
        status: submission.status,
        score: submission.score,
        submittedAt: submission.submittedAt
      };
    }
    return { submitted: false };
  };

  const formatDueDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const timeDiff = date - now;
    const daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));

    if (daysDiff < 0) return `Overdue ${Math.abs(daysDiff)} days ago`;
    if (daysDiff === 0) return "Due today";
    if (daysDiff === 1) return "Due tomorrow";
    return `Due in ${daysDiff} days`;
  };

  if (loading) {
    return (
      <div className="assignments-section">
        <div className="loading">Loading assignments...</div>
      </div>
    );
  }

  return (
    <div className="assignments-section">
      <div className="assignments-header">
        <h2>
          <ClipboardList size={24} />
          Assignments
        </h2>
        <div className="assignment-tabs">
          <button 
            className={`tab-btn ${activeTab === "available" ? "active" : ""}`}
            onClick={() => setActiveTab("available")}
          >
            Available Assignments
          </button>
          <button 
            className={`tab-btn ${activeTab === "submitted" ? "active" : ""}`}
            onClick={() => setActiveTab("submitted")}
          >
            My Submissions
          </button>
        </div>
      </div>

      {activeTab === "available" && (
        <div className="assignments-list">
          {assignments.length === 0 ? (
            <div className="no-assignments">
              <ClipboardList size={48} />
              <p>No assignments available</p>
              <small>Your teachers will post assignments here when available.</small>
            </div>
          ) : (
            assignments.map(assignment => {
              const submission = getSubmissionStatus(assignment);
              const isOverdue = new Date() > new Date(assignment.dueDate);
              
              return (
                <div key={assignment._id} className="assignment-card">
                  <div className="assignment-header">
                    <h3>{assignment.title}</h3>
                    <div className="assignment-meta">
                      <span className="course-badge">{assignment.course.name}</span>
                      <span className={`due-date ${isOverdue ? 'overdue' : ''}`}>
                        {formatDueDate(assignment.dueDate)}
                      </span>
                      <span className="points">Points: {assignment.maxPoints}</span>
                    </div>
                  </div>
                  
                  <p className="assignment-description">{assignment.description}</p>
                  
                  {assignment.attachments.length > 0 && (
                    <div className="assignment-attachments">
                      <strong>Attachments:</strong>
                      {assignment.attachments.map((file, index) => (
                        <a 
                          key={index}
                          href={`http://localhost:5000${file.path}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="attachment-link"
                        >
                          📎 {file.originalName}
                        </a>
                      ))}
                    </div>
                  )}
                  
                  <div className="assignment-footer">
                    <div className="submission-info">
                      {submission.submitted ? (
                        <span className="submitted-badge">
                          ✅ Submitted {new Date(submission.submittedAt).toLocaleDateString()}
                          {submission.score && ` • Score: ${submission.score}/${assignment.maxPoints}`}
                        </span>
                      ) : (
                        <span className="not-submitted-badge">
                          {isOverdue ? "❌ Missed" : "⏳ Pending"}
                        </span>
                      )}
                    </div>
                    
                    {!submission.submitted && !isOverdue && (
                      <button 
                        className="submit-btn"
                        onClick={() => openSubmitModal(assignment)}
                      >
                        Submit Assignment
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {activeTab === "submitted" && (
        <div className="submissions-list">
          {submissions.length === 0 ? (
            <div className="no-submissions">
              <ClipboardList size={48} />
              <p>No submissions yet</p>
              <small>Your submitted assignments will appear here.</small>
            </div>
          ) : (
            submissions.map(submission => (
              <div key={submission._id} className="submission-card">
                <div className="submission-header">
                  <h3>{submission.assignment.title}</h3>
                  <div className="submission-meta">
                    <span className={`status-badge ${submission.status}`}>
                      {submission.status.charAt(0).toUpperCase() + submission.status.slice(1)}
                    </span>
                    <span className="submitted-date">
                      Submitted: {new Date(submission.submittedAt).toLocaleDateString()}
                    </span>
                    {submission.score && (
                      <span className="score">
                        Score: {submission.score}/{submission.assignment.maxPoints}
                      </span>
                    )}
                  </div>
                </div>
                
                <div className="submission-content">
                  {submission.content.text && (
                    <div className="submission-text">
                      <strong>Text Submission:</strong>
                      <p>{submission.content.text}</p>
                    </div>
                  )}
                  
                  {submission.content.link && (
                    <div className="submission-link">
                      <strong>Link Submission:</strong>
                      <a href={submission.content.link} target="_blank" rel="noopener noreferrer">
                        {submission.content.link}
                      </a>
                    </div>
                  )}
                  
                  {submission.content.files.length > 0 && (
                    <div className="submission-files">
                      <strong>Files:</strong>
                      {submission.content.files.map((file, index) => (
                        <a 
                          key={index}
                          href={`http://localhost:5000${file.path}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="file-link"
                        >
                          📄 {file.originalName}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
                
                {submission.feedback && (
                  <div className="feedback-section">
                    <strong>Feedback:</strong>
                    <p>{submission.feedback}</p>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {/* Submit Assignment Modal */}
      {showSubmitModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Submit Assignment: {selectedAssignment?.title}</h3>
              <button 
                className="close-btn"
                onClick={() => setShowSubmitModal(false)}
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="modal-body">
              <div className="form-group">
                <label>Submission Type</label>
                <select
                  value={submissionForm.submissionType}
                  onChange={(e) => setSubmissionForm(prev => ({...prev, submissionType: e.target.value}))}
                >
                  <option value="file">File Upload</option>
                  <option value="text">Text Submission</option>
                  <option value="link">Link Submission</option>
                </select>
              </div>

              {submissionForm.submissionType === 'text' && (
                <div className="form-group">
                  <label>Your Answer</label>
                  <textarea
                    value={submissionForm.text}
                    onChange={(e) => setSubmissionForm(prev => ({...prev, text: e.target.value}))}
                    placeholder="Type your assignment submission here..."
                    rows={6}
                  />
                </div>
              )}

              {submissionForm.submissionType === 'link' && (
                <div className="form-group">
                  <label>Submission Link</label>
                  <input
                    type="url"
                    value={submissionForm.link}
                    onChange={(e) => setSubmissionForm(prev => ({...prev, link: e.target.value}))}
                    placeholder="https://example.com/your-work"
                  />
                </div>
              )}

              {submissionForm.submissionType === 'file' && (
                <div className="form-group">
                  <label>Upload Files</label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    multiple
                    style={{ display: 'none' }}
                  />
                  <button 
                    className="file-upload-btn"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    Choose Files
                  </button>
                  
                  {submissionForm.files.length > 0 && (
                    <div className="file-list">
                      {submissionForm.files.map((file, index) => (
                        <div key={index} className="file-item">
                          <span>📎 {file.name}</span>
                          <button 
                            className="remove-file"
                            onClick={() => removeFile(index)}
                          >
                            <X size={14} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
            
            <div className="modal-footer">
              <button 
                className="cancel-btn"
                onClick={() => setShowSubmitModal(false)}
              >
                Cancel
              </button>
              <button 
                className="submit-btn"
                onClick={handleSubmitAssignment}
                disabled={
                  (submissionForm.submissionType === 'text' && !submissionForm.text) ||
                  (submissionForm.submissionType === 'link' && !submissionForm.link) ||
                  (submissionForm.submissionType === 'file' && submissionForm.files.length === 0)
                }
              >
                Submit Assignment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Leaderboard Component with Real Data
function LeaderboardSection({ currentUser }) {
  const [leaderboardData, setLeaderboardData] = useState([]);
  const [performanceStats, setPerformanceStats] = useState(null);
  const [timeframe, setTimeframe] = useState("month");
  const [selectedCourse, setSelectedCourse] = useState("all");
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchCourses();
  }, []);

  useEffect(() => {
    if (courses.length > 0) {
      fetchLeaderboardData();
      fetchPerformanceStats();
    }
  }, [timeframe, selectedCourse, courses]);

  const fetchCourses = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/courses/student", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCourses(res.data.courses || []);
    } catch (err) {
      console.error("Failed to fetch courses:", err.response?.data?.message);
    }
  };

  const fetchLeaderboardData = async () => {
    try {
      setLoading(true);
      const res = await axios.get("http://localhost:5000/api/leaderboard", {
        headers: { Authorization: `Bearer ${token}` },
        params: { 
          timeframe, 
          courseId: selectedCourse 
        }
      });
      setLeaderboardData(res.data);
    } catch (err) {
      console.error("Failed to fetch leaderboard:", err.response?.data?.message);
      // Fallback to empty data
      setLeaderboardData([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchPerformanceStats = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/leaderboard/stats", {
        headers: { Authorization: `Bearer ${token}` },
        params: { 
          timeframe, 
          courseId: selectedCourse 
        }
      });
      setPerformanceStats(res.data);
    } catch (err) {
      console.error("Failed to fetch stats:", err.response?.data?.message);
    }
  };

  const refreshData = async () => {
    setRefreshing(true);
    await Promise.all([fetchLeaderboardData(), fetchPerformanceStats()]);
    setRefreshing(false);
  };

  const getRankIcon = (rank) => {
    if (rank === 1) return <Crown size={20} className="gold" />;
    if (rank === 2) return <Medal size={20} className="silver" />;
    if (rank === 3) return <Medal size={20} className="bronze" />;
    return <span className="rank-number">{rank}</span>;
  };

  const getPerformanceBadge = (score) => {
    if (score >= 90) return { label: "Excellent", class: "excellent", color: "#10b981" };
    if (score >= 80) return { label: "Good", class: "good", color: "#3b82f6" };
    if (score >= 70) return { label: "Average", class: "average", color: "#f59e0b" };
    return { label: "Needs Improvement", class: "poor", color: "#ef4444" };
  };

  const renderPerformanceChart = () => {
    if (!performanceStats || performanceStats.totalStudents === 0) return null;

    return (
      <div className="performance-chart">
        <h3>Performance Distribution</h3>
        <div className="chart-bars">
          {Object.entries(performanceStats.scoreDistribution).map(([key, value]) => {
            const percentage = (value / performanceStats.totalStudents) * 100;
            const badge = getPerformanceBadge(
              key === 'excellent' ? 95 : 
              key === 'good' ? 85 : 
              key === 'average' ? 75 : 65
            );
            
            return (
              <div key={key} className="chart-bar-container">
                <div className="chart-bar-label">
                  <span className={`performance-dot ${badge.class}`}></span>
                  {key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
                </div>
                <div className="chart-bar">
                  <div 
                    className={`chart-bar-fill ${badge.class}`}
                    style={{ width: `${percentage}%` }}
                  >
                    <span className="chart-bar-value">{value}</span>
                  </div>
                </div>
                <div className="chart-bar-percentage">{percentage.toFixed(1)}%</div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderRadarChart = (student) => {
    const metrics = [
      { label: "Attendance", value: student.attendancePercentage || 0 },
      { label: "Assignments", value: student.assignmentScore || 0 },
      { label: "Activity", value: student.activityScore || 0 },
    ];

    return (
      <div className="radar-chart">
        {metrics.map((metric, index) => (
          <div key={metric.label} className="radar-metric">
            <div className="radar-label">{metric.label}</div>
            <div className="radar-bar">
              <div 
                className="radar-fill"
                style={{ 
                  width: `${metric.value}%`,
                  backgroundColor: getPerformanceBadge(metric.value).color
                }}
              ></div>
            </div>
            <div className="radar-value">{metric.value}%</div>
          </div>
        ))}
      </div>
    );
  };

  const renderScoreProgress = (student) => {
    const badge = getPerformanceBadge(student.performanceScore);
    
    return (
      <div className="score-progress">
        <div className="progress-header">
          <span>Overall Score</span>
          <span className="score-value">{student.performanceScore}</span>
        </div>
        <div className="progress-bar">
          <div 
            className="progress-fill"
            style={{ 
              width: `${student.performanceScore}%`,
              backgroundColor: badge.color
            }}
          ></div>
        </div>
        <div className="performance-badge">
          <span className={`badge ${badge.class}`}>{badge.label}</span>
        </div>
      </div>
    );
  };

  const getCurrentUserRank = () => {
    if (!leaderboardData.length) return null;
    const userIndex = leaderboardData.findIndex(student => student._id === currentUser.id);
    return userIndex !== -1 ? userIndex + 1 : null;
  };

  if (loading) {
    return (
      <div className="loading-container">
        <RefreshCw className="spinner" size={30} />
        <p>Loading leaderboard data...</p>
      </div>
    );
  }

  return (
    <div className="leaderboard-section">
      <div className="leaderboard-header">
        <div className="header-left">
          <h2>
            <Award size={24} />
            Student Performance Leaderboard
          </h2>
          {performanceStats && performanceStats.userRank && (
            <p className="user-rank">
              Your Rank: <strong>#{performanceStats.userRank}</strong> out of {performanceStats.totalStudents} students
            </p>
          )}
        </div>
        
        <div className="leaderboard-controls">
          <button 
            className="refresh-btn"
            onClick={refreshData}
            disabled={refreshing}
          >
            <RefreshCw size={16} className={refreshing ? "spinning" : ""} />
            {refreshing ? "Refreshing..." : "Refresh"}
          </button>
          
          <select 
            value={timeframe} 
            onChange={(e) => setTimeframe(e.target.value)}
            className="control-select"
          >
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="all">All Time</option>
          </select>
          
          <select 
            value={selectedCourse} 
            onChange={(e) => setSelectedCourse(e.target.value)}
            className="control-select"
          >
            <option value="all">All Courses</option>
            {courses.map(course => (
              <option key={course._id} value={course._id}>
                {course.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Performance Stats Overview */}
      {performanceStats && performanceStats.totalStudents > 0 && (
        <div className="stats-overview">
          <div className="stat-card">
            <div className="stat-icon">
              <Crown size={20} />
            </div>
            <div className="stat-info">
              <div className="stat-value">{performanceStats.topScore}</div>
              <div className="stat-label">Top Score</div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <Target size={20} />
            </div>
            <div className="stat-info">
              <div className="stat-value">{performanceStats.averageScore.toFixed(1)}</div>
              <div className="stat-label">Average Score</div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <Users size={20} />
            </div>
            <div className="stat-info">
              <div className="stat-value">{performanceStats.totalStudents}</div>
              <div className="stat-label">Total Students</div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <TrendingUp size={20} />
            </div>
            <div className="stat-info">
              <div className="stat-value">
                {performanceStats.scoreDistribution.excellent}
              </div>
              <div className="stat-label">Excellent Performers</div>
            </div>
          </div>
        </div>
      )}

      {/* Performance Distribution Chart */}
      {renderPerformanceChart()}

      {/* Leaderboard List */}
      <div className="leaderboard-list">
        <h3>Student Rankings</h3>
        {leaderboardData.length === 0 ? (
          <div className="no-data">
            <Award size={48} />
            <p>No leaderboard data available yet.</p>
            <small>Start attending classes and submitting assignments to appear on the leaderboard.</small>
          </div>
        ) : (
          leaderboardData.map((student, index) => (
            <div 
              key={student._id} 
              className={`leaderboard-item ${student._id === currentUser.id ? 'current-user' : ''}`}
            >
              <div className="rank-section">
                {getRankIcon(index + 1)}
                {student._id === currentUser.id && <div className="you-indicator">YOU</div>}
              </div>
              
              <div className="student-info">
                <div className="student-avatar">
                  <img 
                    src={student.avatar} 
                    alt={student.name}
                    onError={(e) => {
                      e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(student.name)}&background=4a6fa5`;
                    }}
                  />
                </div>
                <div className="student-details">
                  <h4>
                    {student.name}
                    {student._id === currentUser.id && <span className="you-badge"> (You)</span>}
                  </h4>
                  <p className="student-id">{student.studentId}</p>
                  {renderRadarChart(student)}
                </div>
              </div>
              
              <div className="performance-section">
                {renderScoreProgress(student)}
                
                <div className="metric-breakdown">
                  <div className="metric">
                    <span className="metric-label">Attendance:</span>
                    <span className="metric-value">{student.attendancePercentage || 0}%</span>
                  </div>
                  <div className="metric">
                    <span className="metric-label">Assignments:</span>
                    <span className="metric-value">{student.assignmentScore || 0}%</span>
                  </div>
                  <div className="metric">
                    <span className="metric-label">Activity:</span>
                    <span className="metric-value">{student.activityScore || 0}%</span>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// Your existing ChitChatBro component remains the same
function ChitChatBro({ currentUser }) {
  const [activeTab, setActiveTab] = useState("profile");
  return (
    <div className="profile-chat-container">
      <div className="tab-header">
        <button
          className={activeTab === "profile" ? "active" : ""}
          onClick={() => setActiveTab("profile")}
        >
          <User size={16} /> Profile
        </button>
        <button
          className={activeTab === "chat" ? "active" : ""}
          onClick={() => setActiveTab("chat")}
        >
          <MessageCircle size={16} /> Chatbot
        </button>
      </div>

      <div className="tab-content">
        {activeTab === "profile" && (
          <div className="profile-section">
            <h2>My Profile</h2>
            <p><strong>Name:</strong> {currentUser.name}</p>
            <p><strong>Email:</strong> {currentUser.email}</p>
          </div>
        )}
        {activeTab === "chat" && (
          <div className="chat-section">
            <h2>Help Assistant 🤖</h2>
            <div className="chat-box">
              <p><strong>Bot:</strong> Hi {currentUser.name}, how can I help you today?</p>
            </div>
            <input type="text" placeholder="Type your question..." className="chat-input" />
          </div>
        )}
      </div>
    </div>
  );
}

// Attendance Report Component
function AttendanceReport({ currentUser }) {
  return (
    <div className="attendance-report-section">
      <div className="report-header">
        <h2>
          <BarChart2 size={24} />
          Attendance Report
        </h2>
      </div>
      
      <div className="no-attendance-message">
        <Users size={48} />
        <h3>No Attendance Records Found</h3>
        <p>You haven't marked any attendance for your courses yet.</p>
        <div className="attendance-tips">
          <p>To mark attendance:</p>
          <ul>
            <li>Go to the "Attendance" section</li>
            <li>Check for active attendance sessions in your enrolled courses</li>
            <li>Use the camera to mark your attendance when sessions are active</li>
            <li>Make sure you're within the allowed radius of the classroom</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

// Gemini AI Chat Component
function GeminiAIChat({ currentUser }) {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [apiKey] = useState("your-gemini-api-key-here"); // Replace with your actual API key

  const chatContainerRef = useRef(null);

  useEffect(() => {
    // Initialize with welcome message
    setMessages([
      {
        id: 1,
        text: `Hello ${currentUser.name}! I'm your learning assistant. How can I help you with your studies today?`,
        sender: "bot",
        timestamp: new Date(),
      },
    ]);
  }, [currentUser.name]);

  useEffect(() => {
    // Scroll to bottom when messages change
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const initializeGemini = () => {
    const genAI = new GoogleGenerativeAI(apiKey);
    return genAI.getGenerativeModel({ model: "gemini-pro" });
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || loading) return;

    const userMessage = {
      id: Date.now(),
      text: inputMessage,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setLoading(true);

    try {
      const model = initializeGemini();
      const prompt = `You are an educational assistant for a student named ${currentUser.name}. 
      Provide helpful, concise responses about studying, assignments, time management, and learning strategies.
      Student's question: ${inputMessage}`;

      const result = await model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();

      const botMessage = {
        id: Date.now() + 1,
        text: text,
        sender: "bot",
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error("Gemini API error:", error);
      
      const errorMessage = {
        id: Date.now() + 1,
        text: "I apologize, but I'm having trouble connecting right now. Please try again later or check your API key.",
        sender: "bot",
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const quickQuestions = [
    "How can I improve my focus while studying?",
    "Best ways to prepare for exams?",
    "How to manage multiple assignments?",
    "Tips for better time management?",
  ];

  return (
    <div className="gemini-chat-section">
      <div className="chat-header">
        <h2>
          <MessageCircle size={24} />
          Study Assistant
        </h2>
        <div className="chat-subtitle">
          Powered by Gemini AI - Your personal learning companion
        </div>
      </div>

      <div className="chat-container" ref={chatContainerRef}>
        <div className="messages-container">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`message ${message.sender === "user" ? "user-message" : "bot-message"}`}
            >
              <div className="message-content">
                <p>{message.text}</p>
                <span className="message-time">
                  {message.timestamp.toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </span>
              </div>
            </div>
          ))}
          {loading && (
            <div className="message bot-message">
              <div className="message-content">
                <div className="typing-indicator">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="quick-questions">
        <p>Quick questions you can ask:</p>
        <div className="quick-buttons">
          {quickQuestions.map((question, index) => (
            <button
              key={index}
              className="quick-btn"
              onClick={() => {
                setInputMessage(question);
                setTimeout(() => sendMessage(), 100);
              }}
            >
              {question}
            </button>
          ))}
        </div>
      </div>

      <div className="chat-input-container">
        <div className="input-wrapper">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask me anything about studying, assignments, or learning..."
            disabled={loading}
          />
          <button 
            onClick={sendMessage} 
            disabled={!inputMessage.trim() || loading}
            className="send-btn"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}

function StudentDashboard() {
  const [activeSection, setActiveSection] = useState("classrooms");
  const [courses, setCourses] = useState([]);
  const [activeSessions, setActiveSessions] = useState({});
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [joinCode, setJoinCode] = useState("");
  const [radiusMessage, setRadiusMessage] = useState("");
  const [cameraOverlay, setCameraOverlay] = useState(false);
  const [capturing, setCapturing] = useState(false);
  
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const token = localStorage.getItem("token");

  const [currentUser, setCurrentUser] = useState({
    name: "HII! ",
    email: "kecstudent@example.com",
     id: localStorage.getItem("userId") || "650f2c4e1b8c2d1f4a123456",
  });

  const fetchCourses = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/courses/student", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCourses(res.data.courses || []);
    } catch (err) {
      console.error("Failed to fetch courses:", err.response?.data?.message);
    }
  };

  const fetchActiveAttendanceSessions = async () => {
    try {
      if (!courses.length) return;
      const res = await axios.post(
        "http://localhost:5000/api/attendance/student-active-sessions",
        { courseIds: courses.map((c) => c._id) },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      const sessionMap = {};
      res.data.forEach((s) => (sessionMap[s.courseId._id] = s));
      setActiveSessions(sessionMap);
    } catch (err) {
      console.error("❌ Failed to fetch active sessions:", err.response?.data?.message);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, []);

  useEffect(() => {
    fetchActiveAttendanceSessions();
  }, [courses]);

 const joinCourse = async () => {
  if (!joinCode.trim()) {
    alert("Please enter course code");
    return;
  }

  try {
    const response = await axios.post(
      "http://localhost:5000/api/students/courses/join",
      { courseCode: joinCode.toUpperCase() },   // MUST MATCH BACKEND
      { headers: { Authorization: `Bearer ${token}` } }
    );

    alert(response.data.message || "Joined successfully!");
    fetchCourses();
    setJoinCode("");
  } catch (err) {
    console.error("Join course error:", err.response?.data);
    alert(err.response?.data?.message || "Error joining course");
  }
};



  // CAMERA CAPTURE POPUP
  const startCamera = async () => {
    setCameraOverlay(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err) {
      console.error("Camera error:", err);
      alert("Camera access denied");
      setCameraOverlay(false);
    }
  };

  const stopCamera = () => {
    const stream = videoRef.current?.srcObject;
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }
    setCameraOverlay(false);
  };

const captureAndVerify = async (session) => {
  setCapturing(true);

  setTimeout(async () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const context = canvas.getContext("2d");

    // Capture image from camera
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    const imageData = canvas.toDataURL("image/jpeg"); // Base64
    stopCamera();
    setCapturing(false);

    // Convert Base64 to File (Required for backend)
    function dataURLtoFile(dataurl, filename) {
      const arr = dataurl.split(",");
      const mime = arr[0].match(/:(.*?);/)[1];
      const bstr = atob(arr[1]);
      let n = bstr.length;
      const u8arr = new Uint8Array(n);
      while (n--) u8arr[n] = bstr.charCodeAt(n);
      return new File([u8arr], filename, { type: mime });
    }

    const file = dataURLtoFile(imageData, "captured.jpg");

    // Get current location
    if (!navigator.geolocation) {
      alert("Geolocation not supported");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;

        // Check allowed radius
        const distance = getDistance(
          latitude,
          longitude,
          session.latitude,
          session.longitude
        );

        if (distance > session.radius) {
          setRadiusMessage(
            `❌ Outside allowed range (${Math.round(distance)}m away).`
          );
          alert("You are outside attendance radius.");
          return;
        }

        // Prepare FormData for backend (IMPORTANT)
        const formData = new FormData();
        formData.append("roll_no", currentUser.roll_no); // must match backend
        formData.append("photo", file); // send as file

        try {
          const res = await axios.post(
            "http://192.168.43.76:5000/verify",
            formData,
            {
              headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "multipart/form-data",
              },
            }
          );

          alert(res.data?.message || "Attendance verified!");
          fetchActiveAttendanceSessions();
        } catch (err) {
          console.error(err.response?.data);
          alert(err.response?.data?.message || "Attendance verified!");
        }
      },

      (err) => {
        console.error("Location error:", err);
        alert("Location permission required to mark attendance");
      },

      { enableHighAccuracy: true }
    );
  }, 2000);
};

  const getDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371e3;
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(Δφ / 2) ** 2 +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert("Copied to clipboard!");
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location.href = "/login";
  };

  const sidebarItems = [
    { id: "classrooms", label: "Classrooms", icon: BookOpen },
    { id: "attendance", label: "Attendance", icon: Users },
    { id: "report", label: "Attendance Report", icon: BarChart2 },
    { id: "assignments", label: "Assignments", icon: ClipboardList },
    { id: "leaderboard", label: "Leaderboard", icon: Award },
    { id: "profile", label: "My Profile", icon: User },
    { id: "chitchat", label: "ChitChatBro", icon: MessageCircle },
    { id: "gemini-chat", label: "Study Assistant", icon: MessageCircle },
  ];
    const handleProfileUpdate = (updatedProfile) => {
    setCurrentUser(updatedProfile);
  };

  const renderAttendance = () => (
    <div>
      <h2>Attendance</h2>
      {radiusMessage && (
        <p
          style={{
            background: radiusMessage.includes("✅") ? "#e0ffe0" : "#ffe0e0",
            padding: "10px",
            borderRadius: "8px",
            marginBottom: "10px",
          }}
        >
          {radiusMessage}
        </p>
      )}
      <div className="cards-container">
        {courses.map((course) => {
          const session = activeSessions[course._id];
          const active = session?.active || false;
          return (
            <div key={course._id} className="card">
              <h3>{course.name}</h3>
              <p>{course.description}</p>
              <button
                className={`start-session-btn ${active ? "enabled" : "disabled"}`}
                onClick={() => active && startCamera()}
                disabled={!active}
              >
                {active ? "Mark Attendance" : "No Active Session"}
              </button>
            </div>
          );
        })}
      </div>

      {cameraOverlay && (
        <div className="camera-overlay">
          <div className="camera-container">
            <button className="close-btn" onClick={stopCamera}><X size={20} /></button>
            <video ref={videoRef} autoPlay playsInline />
            <canvas ref={canvasRef} style={{ display: "none" }} />
            {capturing ? (
              <p>📸 Capturing your face...</p>
            ) : (
              <button 
                className="capture-btn"
                onClick={() => {
                  const session = activeSessions[courses[0]?._id];
                  if (session) captureAndVerify(session);
                }}
              >
                Capture & Verify
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case "classrooms": return renderClassrooms();
      case "attendance": return renderAttendance();
      case "report": return <AttendanceReport currentUser={currentUser} />;
      case "assignments": return <AssignmentSection currentUser={currentUser} />;
      case "leaderboard": return <LeaderboardSection currentUser={currentUser} />;
      case "profile": return <ProfileSection currentUser={currentUser} onProfileUpdate={handleProfileUpdate} />;
      case "chitchat": return <ChitChatBro currentUser={currentUser} />;
      case "gemini-chat": return <GeminiAIChat currentUser={currentUser} />;
      default: return renderClassrooms();
    }
  };
  const renderClassrooms = () => (
    <div>
      <h2>Courses</h2>
      <div className="join-course">
        <input
          type="text"
          placeholder="Enter Join Code"
          value={joinCode}
          onChange={(e) => setJoinCode(e.target.value)}
        />
        <button onClick={joinCourse}>Join Course</button>
      </div>
      <div className="cards-container">
        {courses.map((course) => (
          <div key={course._id} className="card">
            <h3>{course.name}</h3>
            <p>{course.description}</p>
            <p><strong>Join Code:</strong> {course.code}</p>
            <button onClick={() => copyToClipboard(course.code)}>
              <Copy size={16} /> Copy Code
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  const renderSettings = () => (
    <div>
      <h2>Profile</h2>
      <p>Name: {currentUser.name}</p>
      <p>Email: {currentUser.email}</p>
      <button onClick={handleLogout}>
        <LogOut size={16} /> Logout
      </button>
    </div>
  );

  return (
    <div className="dashboard-container">
      <div className={`sidebar ${sidebarOpen ? "open" : "closed"}`}>
        <div className="sidebar-top">
          <User size={24} />
          {sidebarOpen && (
            <div className="user-info">
              <p>{currentUser.name}</p>
              <small>Student</small>
            </div>
          )}
          <div className="hamburger-inside" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <ChevronLeft /> : <ChevronRight />}
          </div>
        </div>

        <div className="sidebar-items">
          {sidebarItems.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className={`sidebar-item ${activeSection === item.id ? "active" : ""}`}
                onClick={() => setActiveSection(item.id)}
              >
                <Icon size={18} />
                {sidebarOpen && <span>{item.label}</span>}
              </div>
            );
          })}
        </div>
      </div>

      <div
        className="main-content"
        style={{
          marginLeft: sidebarOpen ? "300px" : "100px",
          transition: "margin-left 0.3s ease",
        }}
      >
        {renderContent()}
      </div>
    </div>
  );
}

export default StudentDashboard;