import axios from "axios";

// Backend API base URL
const API = axios.create({
  baseURL: "http://localhost:5000", // backend running on 5000
});

export default API;
